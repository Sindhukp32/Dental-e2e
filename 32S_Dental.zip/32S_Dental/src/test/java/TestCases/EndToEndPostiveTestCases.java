package TestCases;

import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Utilities.Common;
import Utilities.Data;
import Utilities.Util;
import pages.dentist.DentistApplication;
import pages.dentist.DentistDashboardPage;
import pages.dentist.DentistLoginPage;

@Listeners({ Utilities.TestListener.class })
public class EndToEndPostiveTestCases extends Common {

	public static int count = 1;
	public Data data;
	public ArrayList<String> datasets;
	public DentistApplication DentistApplication;
	public DentistLoginPage DentistLoginPage;
	public DentistDashboardPage DentistHomePage;

	@BeforeMethod
	public void testStart(Method method) {
		String name = method.getName();
		System.out.println("Before method name:" + name);
		data = new Data("TestData");
		datasets = data.getDataSets(name);
	}

	@Test
	public void TC_001() {
		data.setColIndex("TC_001");

		for (String dataset : datasets) {
			data.setIndex(dataset);
			DentistApplication = new DentistApplication(data);
			DentistLoginPage = DentistApplication.open32CoApplication();
			DentistLoginPage.LoginToApplication();

		}
	}
	
	@Test
	public void EndToEndSoloCase() {
		data.setColIndex("EndToEndSoloCase");
		for (String dataset : datasets) {
			data.setIndex(dataset);
			DentistApplication = new DentistApplication(data);
			DentistApplication.open32CoApplication();

		}
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		System.out.println("After method name:" + result.getMethod().getMethodName());
		try {

			DentistApplication.close();
		} catch (Exception e) {
			System.out.println("Expception : " + e.getMessage());
		} finally {
		}
	}

}
