package Utilities;

import java.io.File;
import java.util.HashMap;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAPI {

	private RequestSpecification httpRequest;

	public RestAPI(String baseUri) {
		try {
			HashMap<String, RequestSpecification> rest = new HashMap<String, RequestSpecification>();
			RestAssured.baseURI = baseUri;
			httpRequest = RestAssured.given();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getResponseString(String get) throws Exception {
		String str;
		try {
			Response response = httpRequest.get(get);
			str = response.body().asString();
		} catch (Exception ex) {
			throw ex;
		}
		return str;
	}

	public String getResponseString() {
		Response response = httpRequest.get();
		String str = response.body().asString();
		return str;
	}

	public Response getResponse() {
		Response response = httpRequest.get();
		return response;
	}

	public Response getResponse(String get) {
		Response response = httpRequest.get(get);

		return response;
	}

	public Response post(String url, String body) {
		Response response = httpRequest.body(body).post(url);

		return response;
	}

	public Response post(String url, File jsonFilePath) {
		Response response = httpRequest.body(jsonFilePath).post(url);

		return response;
	}

	public Response put(String url, String body) {
		Response response = httpRequest.body(body).put(url);

		return response;
	}

	public Response put(String url, File jsonFilePath) {
		Response response = httpRequest.body(jsonFilePath).put(url);

		return response;
	}

	public Response delete(String url, String body) {
		Response response = httpRequest.body(body).delete(url);

		return response;
	}

	public Response delete(String url, File jsonFilePath) {
		Response response = httpRequest.body(jsonFilePath).delete(url);

		return response;
	}

	public static int getStatusCode(Response response) {
		try {
			return response.getStatusCode();
		} catch (Exception e) {
			return -1;
		}
	}

	public static String getResponseHeader(Response response) {
		try {
			return response.getHeaders().toString();
		} catch (Exception e) {
			return null;
		}
	}

	public static String getResponseBody(Response response) {
		try {
			return response.getBody().asString();
		} catch (Exception e) {
			return null;
		}
	}

}
