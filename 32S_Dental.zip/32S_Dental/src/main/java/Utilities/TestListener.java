package Utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {
	public static ExtentReport extent;

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("Before Testmethod: " + result.getMethod().getMethodName());
		extent.testScenarioStart(result);
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	@Override
	public void onStart(ITestContext context) {
		Util.createOutputDirectory();
		Util.readProperty();
		extent = new ExtentReport();
		extent.start();
	}

	@Override
	public void onFinish(ITestContext context) {
		extent.testScenarioEnd(context.getName());
	}

	@Override
	public void onTestSuccess(ITestResult result) {

	}

	@Override
	public void onTestFailure(ITestResult result) {
		extent.log("fail", result.getThrowable().getMessage());
	}

	@Override
	public void onTestSkipped(ITestResult result) {

	}

	public static void test() {
		extent = new ExtentReport();
		extent.start();
	}

}
