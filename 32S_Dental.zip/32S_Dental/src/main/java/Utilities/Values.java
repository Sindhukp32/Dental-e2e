package Utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class Values extends Common {
	public static WebDriver driver;
	public static int textLoadWaitTime;
	public static int elementLoadWaitTime;
	public static int implicitlyWaitTime;
	public static int pageLoadWaitTime = 0;
	public static final ArrayList<String> testCaseNames = new ArrayList();
	public static ArrayList<String> testCaseDataSets = new ArrayList();
	public static boolean testCaseExecutionStatus = false;
	public static String outputDirectory;
	public static HashMap<String, String> configData = new HashMap<String, String>();
	public static List<HashMap<String, String>> executionData = new ArrayList<HashMap<String, String>>();
	public static List<HashMap<String, String>> devicesData = new ArrayList<HashMap<String, String>>();
	public static int failureNo;
	public static Properties frameworkProperty;
}
