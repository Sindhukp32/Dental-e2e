package Utilities;

import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {

	static ExtentReports extent;
	static int thread = 0;
	ExtentTest parent;
	ExtentTest child;
	private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();

	public void start() {
		try {
			thread = thread + 1;
			System.out.println("Called " + thread);
			extent = new ExtentReports();
			ExtentSparkReporter spark = new ExtentSparkReporter(Values.outputDirectory + "/Results.html");
			spark.config().setReportName("TMU Automation");
			spark.config().setDocumentTitle("TMU Automation Report");
			extent.attachReporter(spark);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static synchronized ExtentTest getTest() {
		return extentTest.get();
	}

	public void testScenarioStart(ITestResult result) {
		parent = extent.createTest(result.getMethod().getMethodName());
		extentTest.set(parent);
		parent.assignDevice(result.getTestContext().getName());
		System.out.println("Report Started For " + result.getMethod().getMethodName());
	}

	public void log(String status, String msg) {
		switch (status) {
		case "pass":
			getTest().pass(msg);
			break;
		case "info":
			getTest().info(msg);
			break;
		case "fail":
			getTest().fail(msg);
			break;
		case "warn":
			getTest().warning(msg);
			break;
		}
	}

	public void logJson(String msg, String json) {
		getTest().info(MarkupHelper.createCodeBlock(json, CodeLanguage.JSON));
	}

	public void logXml(String msg, String xml) {
		getTest().info(MarkupHelper.createCodeBlock(xml));
	}

	public void logFailScreenshot(String errMsg, String path) {
		getTest().addScreenCaptureFromPath(path).fail(errMsg,
				MediaEntityBuilder.createScreenCaptureFromPath(path).build());
	}

	public void logScreenshot(String path) {
		getTest().addScreenCaptureFromPath(path).info(MediaEntityBuilder.createScreenCaptureFromPath(path).build());
	}

	public void logScreenshotbase(String base64) {
		getTest()// .addScreenCaptureFromBase64String(base64)
				.info(MediaEntityBuilder.createScreenCaptureFromBase64String(base64).build());
	}

	public static synchronized void testScenarioEnd(String name) {
		extent.flush();
		System.out.println("Report Ended For " + name);
	}

}
