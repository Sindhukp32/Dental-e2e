package Utilities;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;

import javax.imageio.ImageIO;

import org.testng.Assert;

public class Common extends ExtentReport {

	public void screenShot(String filename) {
		String scrPath = Values.outputDirectory + "/Screenshots";
		File file = new File(scrPath);
		file.mkdir();
		try {
			Robot robot = new Robot();
			Rectangle captureSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			BufferedImage bufferedImage = robot.createScreenCapture(captureSize);
			File outputfile = new File(scrPath + "/" + filename + ".png");
			ImageIO.write(bufferedImage, "png", outputfile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void failAssert(String errMessage) {
		fail(errMessage);
		Assert.assertTrue(false, errMessage);
	}

	public void fail(String errMessage) {
		log("fail", errMessage);
	}

	public void passed(String logMessage) {
		log("pass", logMessage);
	}

	public void info(String logMessage) {
		log("info", logMessage);
	}

}
