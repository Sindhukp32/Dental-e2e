package pages.dentist;

import org.openqa.selenium.By;
import Utilities.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Utilities.Data;

public class DentistLoginPage extends Page {

	@FindBy(id = "basic_email")
	private WebElement txtEmail;
	
	@FindBy(id = "basic_password")
	private WebElement txtPassword;
	
	@FindBy(xpath = "//button/span[text()='Login']")
	private WebElement btnLogin;

	public DentistLoginPage(WebDriver browser, Data data) {
		super(browser, data);
	}

	@Override
	protected boolean isValidPage() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void waitForPageLoad() {
		// TODO Auto-generated method stub

	}
	
	public void LoginToApplication() {
		String username = "sindhu.kumarthi+2den@32co.com";
		String password = "123456789";
		enterText(txtEmail, "Username Textbox",username);
		enterText(txtPassword, "Password Textbox",password);
		clickOn(btnLogin, "Login Button");
		waitForElement(By.xpath("//span[text()='Dashboard']"));
		if(isElementPresent(By.xpath("//span[text()='Dashboard']"))) {			
			passed("Logged into the application successfully");
			takeScreenshot();
		}else {
			failAssert("Unable to login to application");
		}
	}

}
